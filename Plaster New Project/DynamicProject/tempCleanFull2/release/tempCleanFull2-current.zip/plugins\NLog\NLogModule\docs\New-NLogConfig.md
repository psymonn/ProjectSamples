﻿---
external help file: NLogModule-help.xml
online version: 
schema: 2.0.0
---

# New-NLogConfig

## SYNOPSIS
Creates a new configuration in memory

## SYNTAX

```
New-NLogConfig
```

## DESCRIPTION
Important to add logging behaviour and log targets to your LogManager

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
$myLogconfig = New-NLogConfig
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

