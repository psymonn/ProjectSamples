﻿---
external help file: tempCleanFull2-help.xml
Module Name: tempCleanFull2
online version: https://www.github.com/psymon/tempCleanFull2
schema: 2.0.0
---

# New-AwesomeFunction

## SYNOPSIS
TBD

## SYNTAX

```
New-AwesomeFunction [<CommonParameters>]
```

## DESCRIPTION
TBD

## EXAMPLES

### EXAMPLE 1
```
TBD
```

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable.
For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Author: Psymon

## RELATED LINKS

[https://www.github.com/psymon/tempCleanFull2](https://www.github.com/psymon/tempCleanFull2)

