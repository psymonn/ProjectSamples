﻿---
Module Name: newCleanModule
Module Guid: b9be5c6e-2a05-4bff-b26d-461f5087fdde
Download Help Link: https://www.github/Psymon/newCleanModule/release/newCleanModule/docs/newCleanModule.md
Help Version: 0.0.5
Locale: en-US
---

# newCleanModule Module
## Description
new clean module description

## newCleanModule Cmdlets
### [New-AwesomeFunction](New-AwesomeFunction.md)
TBD


