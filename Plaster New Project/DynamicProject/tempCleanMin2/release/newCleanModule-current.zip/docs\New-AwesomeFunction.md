﻿---
external help file: newCleanModule-help.xml
Module Name: newCleanModule
online version: https://www.github/Psymon/newCleanModule
schema: 2.0.0
---

# New-AwesomeFunction

## SYNOPSIS
TBD

## SYNTAX

```
New-AwesomeFunction [<CommonParameters>]
```

## DESCRIPTION
TBD

## EXAMPLES

### EXAMPLE 1
```
TBD
```

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable.
For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Author: Psymon

## RELATED LINKS

[https://www.github/Psymon/newCleanModule](https://www.github/Psymon/newCleanModule)

